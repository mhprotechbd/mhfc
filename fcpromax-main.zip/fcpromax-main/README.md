<img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/azimvau.gif" width="120" height="120" align="left">
<center>
  
  
 
   ##  MY SOCIAL MEDIA : <br>

<a href="https://Instagram.com/azimmahmud143" target="_blank"><img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/instagram.png" alt="alt text" width="25" height="25"></a> 
<a href="https://t.me/mrerror69"><img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/telegram.png" alt="alt text" width="25" height="25"></a>
<a href="https://www.facebook.com/azimmahmudofficial" target="_blank"><img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/facebook.png" alt="alt text" width="25" height="25"></a> <a href="https://youtube.com/MrError69"><img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/youtube.png" alt="alt text" width="25" height="25"></a> 
&nbsp;&nbsp;     &nbsp;&nbsp;    &nbsp;&nbsp;   &nbsp;&nbsp;   &nbsp;&nbsp;
  
____Programming And Memes____

CONTACT WITH <a href="https://github.com/Azim-vau"><b>MR. ERROR </a> </br><br>
<img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/contact.png" alt="alt text" width="25" height="25"> <br>
<p>errorazim@gmail.com</p>  <br> <br> 


<a href="https://github.com/Azim-Vau/followers">
<img title="Followers" src="https://img.shields.io/github/followers/Azim-vau?label=Followers&color=blue&style=flat-square"></a>

<br>
  <a href="https://github.com/Azim-Vau/termux-style/stargazers/">
  <a href="https://github.com/Azim-vau/fcpromax">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/Azim-vau/fcpromax.svg"/>
  </a>
<br>
  <a href="https://github.com/Azim-vau/fcpromax">
    <img alt="Language" src="https://img.shields.io/github/languages/count/Azim-vau/fcpromax.svg"/>
  </a>
  <a href="https://github.com/Azim-vau/fcpromax">
    <img alt="Starts" src="https://img.shields.io/github/stars/Azim-vau/fcpromax.svg"/>
  </a>
<br>
<a href="https://github.com/Azim-vau/fcpromax">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/Azim-vau/fcpromax.svg"/>
  </a>
<br>
<a href="https://github.com/Azim-vau/fcpromax">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/Azim-vau/fcpromax.svg"/> <a                                                                                                        href="https://github.com/Azim-vau/fcpromax">
    <img alt="Forks" src="https://img.shields.io/github/forks/Azim-vau/fcpromax.svg"/>
  </a>
</div>

</br>
<p align="center">
      FACEBOOK ACCOUNT CLONER
</p>
  
#### INSTALL TOOL ON TERMUX
```python
$ apt update && apt upgrade
$ apt install python
$ pip install mechanize lolcat
$ pip install requests bs4
$ pip install futures
$ apt install git
$ git clone https://github.com/Azim-vau/fcpromax.git
```
#### RUN SCRIPT
```python
$ cd fcpromax
$ python fcpromax.py
```


#### MY SOCIAL MEDIA

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=red&labelColor=black)](https://github.com/Azim-Vau) <br>
[![](https://img.shields.io/badge/Facebook-black?logo=Facebook&logoColor=red&labelColor=black)](https://www.facebook.com/Azimvau69) <br>
[![](https://img.shields.io/badge/Instagram-black?logo=Instagram&logoColor=red&labelColor=black)](https://www.instagram.com/azimmahmud143) <br>


<h2> THANKS FOR VISIT ✘✘ <h2\>
